package com.pojos;

public class Admin {

	private String adminId;
	private String adminPassword;

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public Admin(String adminId) {
		super();
		this.adminId = adminId;
	}

	public Admin() {
		super();
	}
	
	
	
	
}
