package com.pojos.actions;

public class Bonus {

}
