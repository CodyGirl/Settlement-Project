package com.dao;

public class TraderDAOImpl implements TraderDAO {

	@Override
	public int getNumOfEquity(String tickerSymbol) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
