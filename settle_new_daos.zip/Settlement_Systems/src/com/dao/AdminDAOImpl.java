package com.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.*;
import com.pojos.Equity;
import com.pojos.Trade;
import com.pojos.Trader;
import java.sql.*;

public class AdminDAOImpl implements AdminDAO {

	private static Connection openConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("driver loaded successfully");

			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
			System.out.println("connection obtained");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	@Override
	public boolean inputTrade(List<Trade> trades) {
		// TODO Auto-generated method stub

		Iterator<Trade> iter = trades.iterator();

		try (Connection conn = ConnectionClass.openConnection()) {

			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			// System.out.println("size" + trades.size());
			// System.out.println(trades.toString());
			// System.out.println("end");

			String newsql = "INSERT INTO TRADELIST VALUES(?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(newsql);
//delete table data			
			while (iter.hasNext()) {

				Trade t = iter.next();

				System.out.println(t.toString());
				String tradeid = t.getTradeId();
				String buyerid = t.getBuyer().getTraderId();
				String sellerid = t.getSeller().getTraderId();
				String tickerSymbol = t.getTickerSymbol();
				int equityQty = t.getEquityQty();
				float equityPrice = t.getEquityPrice();
				// Date settlementDate;
				int isSettled = 0;

				System.out.println("Inserting records into table:");

				// Statement st = openConnection().createStatement();

				ps.setString(1, tradeid);
				ps.setString(2, tickerSymbol);
				ps.setInt(3, equityQty);
				ps.setFloat(4, equityPrice);
				ps.setString(5, buyerid);
				ps.setString(6, sellerid);
				ps.setString(7, "admin");
				ps.setInt(8, isSettled);

				ps.executeUpdate();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		// add exception

		return true;
	}

	@Override
	public boolean settleTrade() {
		// TODO Auto-generated method stub

		return false;
	}

	@Override
	public List<Trade> findAllTrades() {
		// TODO Auto-generated method stub

		List<Trade> trades = new ArrayList<>();
		String FIND_ALL_TRADES = "select * from TRADELIST";

		try (Connection conn = ConnectionClass.openConnection()) {
//
//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			Statement st = conn.createStatement();
			ResultSet set = st.executeQuery(FIND_ALL_TRADES);

			while (set.next()) {// till data ends
				Trade trade = new Trade();
				Trader buyer = new Trader();
				Trader seller = new Trader();

				String tradeId = set.getString("TRADEID");
				buyer.setTraderId(set.getString("BUYER"));
				seller.setTraderId(set.getString("SELLER"));
				String tickerSymbol = set.getString("TICKERSYMBOL");
				int equityQty = set.getInt("QUANTITY");
				float equityPrice = set.getFloat("PRICE");

				// Date settlementDate;
				// boolean isSettled;
				// String adminUsername=set.getString("ADMINUSERNAME");

				trade = new Trade(tradeId, buyer, seller, tickerSymbol, equityQty, equityPrice, 0);
				trades.add(trade);

				// System.out.println(trade.toString());

			}
			// after list ends log
			System.out.println("list size:" + trades.size());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

//			System.out.println(trades.toString());

		return trades;
	}

	@Override
	public List<Trade> findCorrespTrade(Equity equityName, Trader trader) {
		// TODO Auto-generated method stub

		String anyTickerSymbol = equityName.getTickerSymbol();
		String anyTrader = trader.getTraderId();

		List<Trade> trades = new ArrayList<>();
		// String FIND_ALL_TRADES="select * from TRADELIST";
		String FIND_ALL_TRADES_BY_TS = "select * from tradelist where tickersymbol=? and (buyer=? or seller=?) ";

		try (Connection conn = ConnectionClass.openConnection()) {

//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");
//
//			Statement st=con.createStatement();
			// ResultSet set=st.executeQuery(FIND_ALL_TRADES);

			PreparedStatement ps = conn.prepareStatement(FIND_ALL_TRADES_BY_TS);

			ps.setString(1, anyTickerSymbol);
			ps.setString(2, anyTrader);
			ps.setString(3, anyTrader);

			ResultSet set = ps.executeQuery();

			while (set.next()) {

				String tradeId = set.getString("TRADEID");

				Trader buyer = new Trader();
				Trader seller = new Trader();

				buyer.setTraderId(set.getString("BUYER"));
				seller.setTraderId(set.getString("SELLER"));

				String tickerSymbol = set.getString("TICKERSYMBOL");
				int equityQty = set.getInt("QUANTITY");
				float equityPrice = set.getFloat("PRICE");
				// Date settlementDate;
				// boolean isSettled;
				// String adminUsername=set.getString("ADMINUSERNAME");

				Trade trade = new Trade(tradeId, buyer, seller, tickerSymbol, equityQty, equityPrice, 0);
				trades.add(trade);

			}
			System.out.println("list size:" + trades.size());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return trades;

		// return null;
	}

	@Override
	public void setDataInReportTable(Trader trader, Equity equity, int gross) {
		// TODO Auto-generated method stub

		try {
//
//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			System.out.println("Inserting records into table:");

//			String sql="UPDATE REPORT SET ? = ? WHERE TRADERID = ?";
			String sql = "UPDATE REPORT SET " + equity.getTickerSymbol() + " = ? WHERE TRADERID = ?";

			System.out.println(sql);

			PreparedStatement ps = openConnection().prepareStatement(sql);

			// ps.setString(1, equity.getTickerSymbol());
			ps.setInt(1, gross);
			System.out.println("" + gross);
			ps.setString(2, trader.getTraderId());
			System.out.println(trader.getTraderId());

			ps.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//		return false;
		}

		// add exception

	}

	@Override
	public boolean modifyTrade(Trade trade, int quantity) {

		try (Connection conn = ConnectionClass.openConnection()) {
//
//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			System.out.println("Inserting records into table:");
			// String sql = "UPDATE TRADELIST SET QUANTITY = " + quantity + " WHERE TRADEID
			// = " + trade.getTradeId();

			String sql = "UPDATE TRADELIST SET QUANTITY = ? WHERE TRADEID = ?";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setInt(1, quantity);
			ps.setString(2, trade.getTradeId());

			System.out.println(sql);

			ps.executeUpdate(sql);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		// add exception

		return true;
	}

	@Override
	public int getNumOfEquity(String tickerSymbol, Trader trader) {
		// TODO Auto-generated method stub

//		List<Trade> trades=new ArrayList<>();
		String FIND_EQTY_NO_BYTRADER = "select quantity from traderequitydetails where tickersymbol=? and traderid=? ";
		int quantity = 0;
		try {

//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			PreparedStatement ps = openConnection().prepareStatement(FIND_EQTY_NO_BYTRADER);
			//
			ps.setString(1, tickerSymbol);
			ps.setString(2, trader.getTraderId());

			ResultSet set = ps.executeQuery();

			while (set.next()) {// till data ends

				quantity = set.getInt("QUANTITY");

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		System.out.println(trades.toString());

		return quantity;

	}

	@Override
	public void setNumOfEquityByName(Trader trader, String tickerSymbol, int quantity) {
		// TODO Auto-generated method stub

		try {

//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			System.out.println("Inserting records into table:");

			String sql = "UPDATE TRADEREQUITYDETAILS SET QUANTITY = ? WHERE TRADERID = ? AND TICKERSYMBOL= ?";

//			String sql = "UPDATE TRADEREQUITYDETAILS SET QUANTITY = " + quantity + " WHERE TRADERID = "
//					+ trader.getTraderId() + " AND TICKERSYMBOL= " + tickerSymbol;

			PreparedStatement ps = openConnection().prepareStatement(sql);

			ps.setInt(1, quantity);
			ps.setString(2, trader.getTraderId());
			ps.setString(3, tickerSymbol);
			System.out.println(sql);

			// Statement st = openConnection().createStatement();
			ps.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//		return false;
		}

		// add exception

	}

	@Override
	public boolean declareAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getDataFromReportTable(Trader trader, Equity equity) {
		// TODO Auto-generated method stub

//		List<Trade> trades=new ArrayList<>();

		String FIND_EQTY_NO_BYTRADER = "select ? from report where traderid = ?";

//		
//		String FIND_EQTY_NO_BYTRADER = "select " + equity.getTickerSymbol() + " from report where traderid = "
//				+ trader.getTraderId();

		System.out.println(FIND_EQTY_NO_BYTRADER);

		int quantity = 0;
		try (Connection conn = ConnectionClass.openConnection()) {
//
//			// open conn
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("driver loaded successfully");
//
//			// jdbc:data_base:install_server:post/databse
//			// 2.connection
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//			// hr is username
//			// hr is portname
//			System.out.println("Connection obtained");

			PreparedStatement ps = conn.prepareStatement(FIND_EQTY_NO_BYTRADER);

			ps.setString(1, equity.getTickerSymbol());
			ps.setString(2, trader.getTraderId());

//			Statement st = openConnection().createStatement();

			ResultSet set = ps.executeQuery();

			while (set.next()) {// till data ends

				quantity = set.getInt(equity.getTickerSymbol());

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		System.out.println(trades.toString());

		return quantity;

	}

	@Override
	public void generateRandomTrades() {
		// TODO Auto-generated method stub

		try (Connection conn = ConnectionClass.openConnection()) {

			String del = "delete from tradelist";
			Statement st = conn.createStatement();
			st.executeUpdate(del);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		List<Trade> trades = new ArrayList<>();
		int id = 0;
		String[] traderlist = { "GS", "JPM", "BCS", "DB", "CITI" };
		String[] equitylist = { "MSFT", "AAPL", "AMZN", "GOOG", "FB" };
		int[] equitynearcostlist = { 140, 210, 1800, 1200, 190 };
		// String[] users = { "admin", "sneha", "rutuja", "nishtha" };
		Trade[] tradelist = new Trade[50];
		Random rand = new Random();

		for (int i = 1; i < 21; i++) {
			// System.out.println(""+i);

			Trade t1 = new Trade();
			String tradecount = "SELECT COUNT(*) FROM TRADELIST";
			Statement stmt = null;
			ResultSet rs = null;

			try (Connection conn = ConnectionClass.openConnection()) {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(tradecount);
				rs.next();
				t1.setTradeId("" + (rs.getInt(1) + 1));

			} catch (SQLException e1) {
// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			String tradeid = "" + i;
			String buyerid = traderlist[rand.nextInt(traderlist.length)];
			String sellerid = traderlist[rand.nextInt(traderlist.length)];

//			if (buyerid.equals(sellerid)) {
//				System.out.println("SAME");
//				while ((buyerid.equals(sellerid))) {
//					System.out.println("Same");
//					sellerid = traderlist[rand.nextInt(traderlist.length)];
//
//				}
//			}
//			
			int index = rand.nextInt(equitylist.length);
			String tickersymbol = equitylist[index];
			int price = equitynearcostlist[index] + rand.nextInt((int) (0.1 * equitynearcostlist[index]))
					- rand.nextInt((int) (0.1 * equitynearcostlist[index]));
			int quantity = 100 + rand.nextInt(9901);
			String username = "admin";

			Trader buyer = new Trader();
			buyer.setTraderId(buyerid);

			Trader seller = new Trader();
			seller.setTraderId(sellerid);

			Trade t = new Trade(tradeid, buyer, seller, tickersymbol, quantity, price, 0);

			trades.add(t);

			System.out.println(tradeid + tickersymbol + buyerid + sellerid + quantity + price + username);
			System.out.println(t.toString());

//		

		}

		// add trades to table
		AdminDAO dao = new AdminDAOImpl();
		dao.inputTrade(trades);

	}

	@Override
	public boolean deleteTrade(List<Trade> list) {
		// TODO Auto-generated method stub

		try (Connection conn = ConnectionClass.openConnection()) {
			for (Trade trade : list) {
				System.out.println("Deleting records from table:");

				String sql = "DELETE FROM TRADELIST WHERE TRADEID = ?";

				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, trade.getTradeId());

				int rows = ps.executeUpdate();

			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	@Override
	public void obligationreport(Trader trader) {
		// TODO Auto-generated method stub

		List<Equity> equities = new ArrayList<>();
		try (Connection conn = ConnectionClass.openConnection()) {
			String sql = "select tickersymbol from equitydetails";
			Statement st = conn.createStatement();
			ResultSet set = st.executeQuery(sql);

			while (set.next()) {
				Equity e = new Equity();
				e.setTickerSymbol(set.getString("TICKERSYMBOL"));
				equities.add(e);

			}

		} catch (Exception e) {

		}
		System.out.println("List of equity" + equities.toString());

		List<Trade> trades = new ArrayList<>();
		AdminDAO dao = new AdminDAOImpl();
		// Trader trader=new Trader();
		for (Equity equity : equities) {
			trades = dao.findCorrespTrade(equity, trader);
			int gross = 0;
			if (trades.isEmpty())
				;
			else {
				for (Trade trade : trades) {
					System.out.println(equity.toString());
					System.out.println(trade.toString());
					if (trade.getBuyer().getTraderId().equals(trader.getTraderId())) {

						gross += trade.getEquityQty();

						System.out.println("" + gross);

					}
					if (trade.getSeller().getTraderId().equals(trader.getTraderId())) {
						gross -= trade.getEquityQty();

						System.out.println("" + gross);

					} else
						;

				}

				dao.setDataInReportTable(trader, equity, gross);

			}

		}

	}

	@Override
	public void generateCorpAction() {
		// TODO Auto-generated method stub

		Random rand = new Random();

		String corpactions[] = { "SPLIT", "DIVIDEND", "BONUS" };

		try (Connection conn = ConnectionClass.openConnection()) {

			for (String action : corpactions) {
				String sql = "DELETE FROM CORPORATEACTION" + action;

				Statement st = conn.createStatement();
				st.executeUpdate(sql);

			}

		} catch (Exception e) {
		}

		String corpaction = corpactions[rand.nextInt(corpactions.length)];

		String[] equitylist = { "MSFT", "AAPL", "AMZN", "GOOG", "FB" };

		String equity = equitylist[rand.nextInt(equitylist.length)];

		if (corpaction.equals("SPLIT")) {

			try (Connection conn = ConnectionClass.openConnection()) {
				int splitnumerator = 1+ rand.nextInt(9);
				int splitdenominator = 1+ rand.nextInt(9);

				for (int i = 9; i > 1; i--) {
					if (splitdenominator % i == 0 && splitnumerator % i == 0) {
						splitdenominator /= i;
						splitnumerator /= i;
					}
				}

				String add = "insert into corporateactionsplit values(?,?,?)";
				PreparedStatement ps = conn.prepareStatement(add);
				ps.setString(1, equity);
				ps.setInt(2, splitnumerator);
				ps.setInt(3, splitdenominator);
				ps.executeUpdate();

			} catch (Exception e) {
			}

		}

		if (corpaction.equals("BONUS")) {
			try (Connection conn = ConnectionClass.openConnection()) {
				int splitnumerator = 1+ rand.nextInt(9);
				int splitdenominator = 1+ rand.nextInt(9);

				for (int i = 9; i > 1; i--) {
					if (splitdenominator % i == 0 && splitnumerator % i == 0) {
						splitdenominator /= i;
						splitnumerator /= i;
					}
				}

				String add = "insert into corporateactionbonus values(?,?,?)";
				PreparedStatement ps = conn.prepareStatement(add);
				ps.setString(1, equity);
				ps.setInt(2, splitnumerator);
				ps.setInt(3, splitdenominator);
				ps.executeUpdate();

			} catch (Exception e) {
			}

		}

		if (corpaction.equals("DIVIDEND")) {
			try (Connection conn = ConnectionClass.openConnection()) {
				int dividendpercent = (1+ rand.nextInt(20))*5;


				String add = "insert into corporateactiondividend values(?,?)";
				PreparedStatement ps = conn.prepareStatement(add);
				ps.setString(1, equity);
				ps.setInt(2, dividendpercent);
				ps.executeUpdate();

			} catch (Exception e) {
			}
			
			
		}
	}

}

/*
 * String DELETE_ALL = "DELETE FROM TRADELIST"; Statement st1; try {
 * 
 * st1 = openConnection().createStatement(); int temp =
 * st1.executeUpdate(DELETE_ALL);
 * 
 * } catch (SQLException e2) { // TODO Auto-generated catch block
 * e2.printStackTrace(); }
 * 
 * 
 * 
 * for(int i =0; i<50;i++) {
 * 
 * Trade t1 = new Trade(); Trader buyer=new Trader(); Trader seller=new
 * Trader(); String tradecount = "SELECT COUNT(*) FROM TRADELIST"; Statement
 * stmt = null; ResultSet rs = null;
 * 
 * try { System.out.println("Run"); stmt = openConnection().createStatement();
 * rs = stmt.executeQuery(tradecount); rs.next(); t1.setTradeId( "" +
 * (rs.getInt(1) + 1));
 * 
 * } catch (SQLException e1) { // TODO Auto-generated catch block
 * e1.printStackTrace(); }
 * 
 * 
 * 
 * buyer.setTraderId("GS"); t1.setBuyer(buyer);
 * 
 * System.out.println(t1.getBuyer().getTraderId()); seller.setTraderId("DB");
 * t1.setSeller(seller);
 * 
 * 
 * while(t1.getBuyer().getTraderId().equals(t1.getSeller().getTraderId())) {
 * seller.setTraderId(trader[rand.nextInt(trader.length)]);
 * t1.setSeller(seller);
 * 
 * 
 * }
 * 
 * int equityindex = rand.nextInt(equity.length); t1.setTickerSymbol( "AAPL");
 * t1.setEquityQty( 100 + rand.nextInt(9901)); t1.setEquityPrice((float)(
 * equitynearcost[equityindex]*0.9 +
 * equitynearcost[equityindex]*rand.nextDouble()/5)); //t1.username = "admin";
 * 
 * 
 * 
 * 
 * String INSERT_TRADE="insert into TRADELIST values(?,?,?,?,?,?,?)";
 * PreparedStatement ps = null; try {
 * 
 * ps = openConnection().prepareStatement(INSERT_TRADE);
 * 
 * } catch (SQLException e) { // TODO Auto-generated catch block
 * e.printStackTrace(); }
 * 
 * int rows_inserted = 0;
 * 
 * try { ps.setString(1, t1.getTradeId()); ps.setString(2,
 * t1.getTickerSymbol()); ps.setInt(3, t1.getEquityQty()); ps.setDouble(4,
 * t1.getEquityPrice()); ps.setString(5, t1.getBuyer().getTraderId());
 * ps.setString(6, t1.getSeller().getTraderId()); ps.setString(7, "admin");
 * 
 * } catch (SQLException e) { // TODO Auto-generated catch block
 * e.printStackTrace(); }
 * 
 * try { rows_inserted =ps.executeUpdate(); } catch (SQLException e) { // TODO
 * Auto-generated catch block e.printStackTrace(); }
 * //System.out.println("rows :"+rows_inserted);
 * 
 * if(rows_inserted!=0) { System.out.println(t1.toString()); } //tradelist[i] =
 * t1;
 * 
 * }
 * 
 * 
 * 
 * 
 * 
 * //return null; }
 * 
 * }
 */