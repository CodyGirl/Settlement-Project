package com.servlets;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import com.dao.AdminDAO;
import com.dao.AdminDAOImpl;
import com.pojos.Equity;
import com.pojos.Trade;
import com.pojos.Trader;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AdminDAO dao1=new AdminDAOImpl();
		//System.out.println(dao.findAllTrades());
//		
	
		dao1.generateRandomTrades();
//		
		System.out.println("after this 1234");
		List<Trade> trades=dao1.findAllTrades();
		trades.forEach(System.out::println);
	
		Trader trader=new Trader();
		trader.setTraderId("GS");
		trader.setTraderId("JPM");
		trader.setTraderId("DB");
		trader.setTraderId("CITI");
		trader.setTraderId("BCS");

		dao1.obligationreport(trader);

		dao1.generateCorpAction();
		
		
//		Trader trader=new Trader();
//		trader.setTraderId("3");
//		Equity newequity=new Equity();
//		newequity.setTickerSymbol("AAPL");
//		System.out.println(dao.findCorrespTrade(newequity,trader ).toString());
//	
//		trader.setTraderId("1");
//		newequity.setTickerSymbol("AAPL");
//		System.out.println(""+dao.getDataFromReportTable(trader, newequity));
//		dao.setDataInReportTable(trader, newequity, 4);
//		
		
		
		/*
		List<Trade> tradesnew=new ArrayList<>();
		Trader buyer=new Trader();
		Trader seller=new Trader();
		buyer.setTraderId("5");
		seller.setTraderId("2");
		Trade t=new Trade("2",buyer,seller,"AAPL",200,(float)101.2,null,false);
		tradesnew.add(t);
		dao.inputTrade(tradesnew);
		*/
	}

}
